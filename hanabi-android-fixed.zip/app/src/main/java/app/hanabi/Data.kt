package app.hanabi

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray

data class Episode(val id: String, val title: String, val url: String, val subtitleUrl: String)

data class Series(
    val id: String,
    val title: String,
    val synopsis: String,
    val genres: List<String>,
    val poster: String,
    val episodes: List<Episode>,
)

object Catalog {
    fun load(ctx: Context): List<Series> {
        val text = ctx.assets.open("catalog.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(text)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val g = o.getJSONArray("genres")
            val e = o.getJSONArray("episodes")
            Series(
                id = o.getString("id"),
                title = o.getString("title"),
                synopsis = o.optString("synopsis"),
                genres = (0 until g.length()).map { g.getString(it) },
                poster = o.optString("poster"),
                episodes = (0 until e.length()).map { j ->
                    val x = e.getJSONObject(j)
                    Episode(x.getString("id"), x.getString("title"), x.getString("url"), x.optString("subtitleUrl"))
                },
            )
        }
    }
}

/** Local storage for watchlist, watch progress and history. Everything is free and on-device. */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("hanabi", Context.MODE_PRIVATE)

    private fun list(key: String) =
        p.getString(key, "")!!.split(",").filter { it.isNotEmpty() }

    val watchlist = mutableStateListOf<String>().also { it.addAll(list("watchlist")) }
    val watched = mutableStateListOf<String>().also { it.addAll(list("watched")) }
    /** Most recent first, entries are "seriesId|episodeId". */
    val recent = mutableStateListOf<String>().also { it.addAll(list("recent")) }

    private fun persist() {
        p.edit()
            .putString("watchlist", watchlist.joinToString(","))
            .putString("watched", watched.joinToString(","))
            .putString("recent", recent.joinToString(","))
            .apply()
    }

    fun toggleWatchlist(seriesId: String) {
        if (!watchlist.remove(seriesId)) watchlist.add(0, seriesId)
        persist()
    }

    fun setWatched(episodeId: String, value: Boolean) {
        if (value && episodeId !in watched) watched.add(episodeId)
        if (!value) watched.remove(episodeId)
        persist()
    }

    fun position(episodeId: String): Long = p.getLong("pos_$episodeId", 0L)

    fun savePosition(seriesId: String, episodeId: String, pos: Long, duration: Long) {
        if (pos <= 0) return
        val finished = duration > 0 && pos > duration * 0.9
        p.edit().putLong("pos_$episodeId", if (finished) 0L else pos).apply()
        if (finished) setWatched(episodeId, true)
        val key = "$seriesId|$episodeId"
        recent.remove(key)
        if (!finished) recent.add(0, key)
        persist()
    }
}
