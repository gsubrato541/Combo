package app.hanabi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val catalog = Catalog.load(this)
        val store = Store(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                App(catalog, store)
            }
        }
    }
}
