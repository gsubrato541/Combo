package app.hanabi

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

@Composable
fun App(catalog: List<Series>, store: Store) {
    val nav = rememberNavController()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    val tabs = listOf("home" to "Home", "browse" to "Browse", "watchlist" to "Watchlist")
    fun series(id: String) = catalog.first { it.id == id }

    Scaffold(bottomBar = {
        if (route in tabs.map { it.first }) {
            NavigationBar {
                tabs.forEach { (r, label) ->
                    NavigationBarItem(
                        selected = route == r,
                        onClick = { nav.navigate(r) { popUpTo("home"); launchSingleTop = true } },
                        icon = {
                            Icon(
                                when (r) { "home" -> Icons.Default.Home; "browse" -> Icons.Default.Search; else -> Icons.Default.Favorite },
                                contentDescription = label,
                            )
                        },
                        label = { Text(label) },
                    )
                }
            }
        }
    }) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
            composable("home") {
                HomeScreen(
                    catalog, store,
                    openSeries = { nav.navigate("series/${it.id}") },
                    resume = { s, e -> nav.navigate("player/${s.id}/${e.id}") },
                )
            }
            composable("browse") { BrowseScreen(catalog) { nav.navigate("series/${it.id}") } }
            composable("watchlist") {
                val items = store.watchlist.mapNotNull { id -> catalog.firstOrNull { it.id == id } }
                Column(Modifier.padding(12.dp)) {
                    Text("Watchlist", style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(8.dp))
                    if (items.isEmpty()) Text("Nothing saved yet. Open a series and tap Add to Watchlist.")
                    else PosterGrid(items) { nav.navigate("series/${it.id}") }
                }
            }
            composable("series/{id}") {
                SeriesScreen(series(it.arguments!!.getString("id")!!), store) { s, e -> nav.navigate("player/${s.id}/${e.id}") }
            }
            composable("player/{sid}/{eid}") {
                val s = series(it.arguments!!.getString("sid")!!)
                val e = s.episodes.first { ep -> ep.id == it.arguments!!.getString("eid")!! }
                PlayerScreen(s, e, store)
            }
        }
    }
}

@Composable
fun Poster(s: Series, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick)) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(2f / 3f).clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center,
        ) {
            if (s.poster.isNotEmpty()) {
                AsyncImage(model = s.poster, contentDescription = s.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            } else {
                Text(s.title.take(1), style = MaterialTheme.typography.headlineLarge)
            }
        }
        Text(s.title, maxLines = 2, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun ShelfRow(title: String, items: List<Series>, onOpen: (Series) -> Unit) {
    Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 12.dp, top = 12.dp, bottom = 6.dp))
    LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items) { s -> Poster(s, Modifier.width(120.dp)) { onOpen(s) } }
    }
}

@Composable
fun PosterGrid(items: List<Series>, onOpen: (Series) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(110.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) { items(items) { s -> Poster(s) { onOpen(s) } } }
}

@Composable
fun HomeScreen(catalog: List<Series>, store: Store, openSeries: (Series) -> Unit, resume: (Series, Episode) -> Unit) {
    val resumable = store.recent.mapNotNull { key ->
        val (sid, eid) = key.split("|").let { it[0] to it.getOrElse(1) { "" } }
        val s = catalog.firstOrNull { it.id == sid } ?: return@mapNotNull null
        val e = s.episodes.firstOrNull { it.id == eid } ?: return@mapNotNull null
        s to e
    }
    LazyColumn {
        if (resumable.isNotEmpty()) item {
            Text("Continue Watching", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 12.dp, top = 12.dp, bottom = 6.dp))
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(resumable) { (s, e) ->
                    Column(Modifier.width(120.dp)) {
                        Poster(s) { resume(s, e) }
                        Text(e.title, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                    }
                }
            }
        }
        item { ShelfRow("All titles", catalog, openSeries) }
        val genres = catalog.flatMap { it.genres }.distinct()
        items(genres) { g -> ShelfRow(g, catalog.filter { g in it.genres }, openSeries) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowseScreen(catalog: List<Series>, onOpen: (Series) -> Unit) {
    var query by remember { mutableStateOf("") }
    var genre by remember { mutableStateOf<String?>(null) }
    val genres = catalog.flatMap { it.genres }.distinct()
    val shown = catalog.filter {
        (genre == null || genre in it.genres) && it.title.contains(query, ignoreCase = true)
    }
    Column(Modifier.padding(12.dp)) {
        OutlinedTextField(query, { query = it }, label = { Text("Search") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
            items(genres) { g ->
                FilterChip(selected = genre == g, onClick = { genre = if (genre == g) null else g }, label = { Text(g) })
            }
        }
        if (shown.isEmpty()) Text("No results") else PosterGrid(shown, onOpen)
    }
}

@Composable
fun SeriesScreen(s: Series, store: Store, play: (Series, Episode) -> Unit) {
    val saved = s.id in store.watchlist
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text(s.title, style = MaterialTheme.typography.headlineSmall)
            Text(s.genres.joinToString(" · "), style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(8.dp))
            Text(s.synopsis)
            Spacer(Modifier.height(8.dp))
            Button(onClick = { store.toggleWatchlist(s.id) }) {
                Text(if (saved) "In Watchlist (tap to remove)" else "Add to Watchlist")
            }
        }
        items(s.episodes) { e ->
            val done = e.id in store.watched
            Card(Modifier.fillMaxWidth().clickable { play(s, e) }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(e.title, style = MaterialTheme.typography.titleSmall)
                        val pos = store.position(e.id)
                        if (pos > 0) Text("Resume at ${pos / 60000}:${"%02d".format(pos / 1000 % 60)}", style = MaterialTheme.typography.labelSmall)
                        if (done) Text("Watched", style = MaterialTheme.typography.labelSmall)
                    }
                    TextButton(onClick = { store.setWatched(e.id, !done) }) {
                        Text(if (done) "Unmark" else "Mark watched")
                    }
                }
            }
        }
    }
}

@Composable
fun PlayerScreen(s: Series, e: Episode, store: Store) {
    val ctx = LocalContext.current
    val player = remember {
        ExoPlayer.Builder(ctx).build().apply {
            val item = MediaItem.Builder().setUri(e.url)
            if (e.subtitleUrl.isNotEmpty()) {
                item.setSubtitleConfigurations(
                    listOf(
                        MediaItem.SubtitleConfiguration.Builder(Uri.parse(e.subtitleUrl))
                            .setMimeType(MimeTypes.TEXT_VTT)
                            .setLanguage("en")
                            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                            .build()
                    )
                )
            }
            setMediaItem(item.build())
            seekTo(store.position(e.id))
            prepare()
            playWhenReady = true
        }
    }
    LaunchedEffect(player) {
        while (true) {
            delay(5000)
            store.savePosition(s.id, e.id, player.currentPosition, player.duration)
        }
    }
    DisposableEffect(player) {
        onDispose {
            store.savePosition(s.id, e.id, player.currentPosition, player.duration)
            player.release()
        }
    }
    AndroidView(factory = { PlayerView(it).apply { this.player = player } }, modifier = Modifier.fillMaxSize())
}
