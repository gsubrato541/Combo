# Hanabi (placeholder name)

Free Android video app: browse, watch, watchlist, resume, mark as watched. No tiers, no ads.
Kotlin + Jetpack Compose + Media3 ExoPlayer. Data lives on the device.

## Run it
1. Open this folder in Android Studio (Koala or newer). Let it sync Gradle.
2. Run on a device or emulator (Android 7.0+).

Not compiled or tested here: no Android SDK or network in the sandbox. Expect to fix small build errors on first sync.

## Your catalogue
`app/src/main/assets/catalog.json` is the only content source. The sample entries are open-licensed Blender films.
Replace them with content you own or are licensed to stream. Do not point it at anyone else's licensed streams.
Fields: series id, title, synopsis, genres, poster (image URL, optional), episodes (id, title, url, optional WebVTT subtitleUrl).

## Before you publish
Rename it (Hanabi is a placeholder) and run trademark and Play Store name checks.
Do not reuse Crunchyroll's name, logo, copy or art.

## Next
Cloud sync of progress, profiles, offline downloads, Crunchylist-style lists.
